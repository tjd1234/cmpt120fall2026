# Lecture 10 Questions and Answers

- [q1.py](q1.py) ([q1_sol.py](q1_sol.py))
- [q2.py](q2.py) ([q2_sol.py](q2_sol.py))
- [q3.py](q3.py) ([q3_sol.py](q3_sol.py))
- [q4.py](q4.py) ([q4_sol.py](q4_sol.py))

All the questions in one file:

- Questions only: [lecture10_questions.pdf](lecture10_questions.pdf)
- Questions and solutions: [lecture10_questions_and_solutions.pdf](lecture10_questions_and_solutions.pdf)

All the files in one download: [lecture10.zip](lecture10.zip)
