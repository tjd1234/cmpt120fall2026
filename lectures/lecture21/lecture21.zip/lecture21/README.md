# Lecture 21 Questions and Answers

- [q1.py](q1.py) ([q1_sol.py](q1_sol.py))
- [q2.py](q2.py) ([q2_sol.py](q2_sol.py))

All the questions in one file:

- Questions only: [lecture21_questions.pdf](lecture21_questions.pdf)
- Questions and solutions: [lecture21_questions_and_solutions.pdf](lecture21_questions_and_solutions.pdf)

All the files in one download: [lecture21.zip](lecture21.zip)
